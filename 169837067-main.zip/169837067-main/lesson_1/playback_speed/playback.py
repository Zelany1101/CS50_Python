playback_rate = input()

print(playback_rate.replace(' ', '...'))
