sentence = input('Give a sentence: ')

print(sentence.lower())
