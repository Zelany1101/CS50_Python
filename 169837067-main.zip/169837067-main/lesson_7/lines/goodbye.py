name = input("What's your name? ")
print(f"goodbye, {name}")
# Say goodbye
name = input("What's your name? ")
print(f"goodbye, {name}")

name = input("What's your name? ")
print(f"goodbye, {name}")
"""
kjlkj
jkhkjh
"""
name = input("What's your name? ")
print(f"goodbye, {name}")
