import test
import random
random.seed(0)
for _ in range(20):
    print(test.generate_integer(1), end=" ")
print()
