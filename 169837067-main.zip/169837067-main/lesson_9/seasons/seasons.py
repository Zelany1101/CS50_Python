"""
Implement a program that prompts the user for their DoB in YYYY-MM-DD format and then prints how old they are in minutes,
rounded to the nearest integer, using English words instea of numerals, without any 'and' between words.
    * Assume for simplicity that the user was born at midnight (i.e. 00:00:00) on that date.
    * Assume current time is also midnight.
        - In other words, even if user runs the program at noon, assume that it is actually midnight.

Use 'datetime.date.today' to get today's date per ...
        ... https://docs.python.org/3/library/datetime.html#datetime.date.today
            (https://docs.python.org/3/library/datetime.html#date-objects)

Welcome to import other built-in libraries or that are specified in the hints.
    * Exit via sys.exit if the user does not input a date in YYYY-MM-DD format.
    * ENsure program will not raise any exceptions.
"""

import sys
import inflect
import re
from datetime import date

def main():
    pattern = r"(?P<year>[1-2][0-9][0-9][0-9])-(?P<month>[0][1-9]|[1][0-2])-(?P<day>[0][1-9]|[12][0-9]|[3][01])"

    DOB = input('Date of Birth: ')

    if match1 := re.match(pattern, DOB):
        DOB_Year = match1.group('year')
        DOB_Month = match1.group('month')
        DOB_Day = match1.group('day')
    else:
        sys.exit('Invalid date')

    today = str(date.today())
    match2 = re.match(pattern, today)
    today_Year = match2.group('year')
    today_Month = match2.group('month')
    today_Day = match2.group('day')

    minutes_per_year = 525600
    #minutes_per_leap_year = 525600 + 1440

    year_minutes = (int(today_Year) - int(DOB_Year)) * minutes_per_year
    month = abs(int(today_Month) - int(DOB_Month))

    count_month = 0
    for m in range(12):
        if m == today_Month:
            break
        else:
            count_month += 1
            continue
    month = count_month * 

    day = abs(int(today_Day) - int(DOB_Day))

    year_minutes = year * minutes_per_year
    month_minutes = month * minutes_per_year

    print(year, month, day)

...


if __name__ == "__main__":
    main()
