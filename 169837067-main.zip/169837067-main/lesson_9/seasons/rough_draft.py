import sys
import inflect
import re
from datetime import date

def main():
    pattern = r"(?P<year>[1-2][0-9][0-9][0-9])-(?P<month>[0][1-9]|[1][0-2])-(?P<day>[0][1-9]|[12][0-9]|[3][01])"

    DOB = input('Date of Birth: ')

    if match1 := re.match(pattern, DOB):
        DOB_Year = int(match1.group('year'))
        DOB_Month = int(match1.group('month'))
        DOB_Day = int(match1.group('day'))
    else:
        sys.exit('Invalid date')

    minutesInADay = 1440
    daysInAYear = 365

    dict_months = {
        "01" : 31,
        "02" : 28,
        "03" : 31,
        "04" : 30,
        "05" : 31,
        "06" : 30,
        "07" : 31,
        "08" : 31,
        "09" : 30,
        "10" : 31,
        "11" : 30,
        "12" : 31
    }

    today = str(date.today())
    match2 = re.match(pattern, today)
    todayYear = int(match2.group('year'))
    todayMonth = int(match2.group('month'))
    todayDay = int(match2.group('day'))

    yearInMinutes = (todayYear - DOB_Year) * daysInAYear * minutesInADay

    monthInDays = 0
    for m in dict_months:
        if m == str(DOB_Month):
            monthInDays += dict_months[m]
            break
        else:
            monthInDays += dict_months[m]
            continue

    monthsInMinutes = monthInDays * minutesInADay

    dayInMinutes = 0
    if todayDay == DOB_Day:
        dayInMinutes = minutesInADay
    elif todayDay > DOB_Day:
        dayInMinutes = (todayDay - DOB_Day) * minutesInADay
    else:
        pass

    totalMinutes = yearInMinutes + monthsInMinutes + dayInMinutes

    p = inflect.engine()
    print(f"{p.number_to_words(totalMinutes)} minutes")


if __name__ == "__main__":
    main()
