"""
four or more functions that collectively test your implementation of Jar thoroughly,
each of whose names should begin with test_

Note that it’s not as easy to test instance methods as it is to test functions alone,
since instance methods sometimes manipulate the same “state” (i.e., instance variables).
To test one method (e.g., withdraw), then, you might need to call another method
first (e.g., deposit). But the method you call first might itself not be correct!

And so programmers sometimes mock (i.e., simulate) state when testing methods, as with
Python’s own mock object library, so that you can call just the one method but modify
the underlying state first, without calling the other method to do so.
"""
from jar import Jar


def test_init():
    ...


def test_str():
    jar = Jar()
    assert str(jar) == ""
    jar.deposit(1)
    assert str(jar) == "🍪"
    jar.deposit(11)
    assert str(jar) == "🍪🍪🍪🍪🍪🍪🍪🍪🍪🍪🍪🍪"


def test_deposit():
    ...


def test_withdraw():
