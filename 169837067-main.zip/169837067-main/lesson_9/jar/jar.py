"""
Implement a cookie jar in which to store cookies. In a file called jar.py, implement a
class called Jar with these methods:
    __init__        should initialize a cookie jar with the given capacity, which represents the max
                    number of cookies that can fit in the cookie jar.
                        if capacity is not a non-negative int, __init__ should raise a ValueError
    __str__         should return a str with n 🍪 where n is the nunmber of cookies in the cookie
                    jar.
                        3 cookies should return str("🍪🍪🍪")\
    deposit         should add n cookies to the cookie jar
                        if adding that many would exceed the cookie's jar capacity, raise ValueError
    withdraw        remove n cookies from the cookie jar.
                        if there aren't that many cookies in the cookie jar, withdraw should raise
                        a ValueError
    capacity        should return the cookie jar's capacity
    size            should return the number of cookies acutally in the cookie jar, initially 0
"""
class Jar:
    def __init__(self, capacity=12):
        ...

    def __str__(self):
        ...

    def deposit(self, n):
        ...

    def withdraw(self, n):
        ...

    @property
    def capacity(self):
        ...

    @property
    def size(self):
        ...
